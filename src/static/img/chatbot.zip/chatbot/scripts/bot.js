
//dummy data 
var trending_data = {
	0 : 'Where are you from',
	1 : 'Are Llamas and Alpacas the same',
	2 : 'Whats your life span',
	3 : 'Do you spit',
	4 : 'Are Llamas easy to train',
	5 : 'What is your scientific name',
	6 : 'What do you eat',
	7 : 'How much do you weigh',
	8 : 'What are some of your unique characteristics',
	9 : 'What sounds do Llamas make?',

};

var trending_answers = {
	0 : 'We have originated from the central plains of North America about 40 million years ago. Later we migrated to South America about three million years ago during the Great American Interchange. ',
	1 : 'Noooo! They are my cousins. Their faces are not as sharp as ours. Also, they like to live in groups while we are more independent minded.',
	2 : 'If everything goes well I can live up to 25 years. Oh BTW, I turn 17 next month!',
	3 : 'Yes, only if you or my brothers piss me off! Some of us get trained to not spit at humans.',
	4 : 'Yes! we are super intelligent and are very fast learners.',
	5 : 'Scientists calls us Lama glama. Sounds cool, doesnt it? ',
	6 : 'We eat Grasses for main course and Lichens for dessert',
	7 : 'It is rude to ask someone how much they weigh. Anyway, we weigh around 25 – 30 lbs at birth. 250 – 500 lbs at maturity.',
	8 : 'We have our babies during daylight hours (usually between 8 a.m. and 4 p.m.), we dung pile (go in only one or two spots in the pasture), we have an extra elliptical blood cell so that we are automatically adapted to working at high altitudes, and we have wide set eyes which can see almost 260 degrees. This makes us very kinetically aware and we rarely trip or knock things over in tight spaces.',
	9 : 'We hum, orgle when breeding and have a high pitched alarm call.',
};

var suggest_data = {
	0 : 'Crowdsource',
	1 : 'Crowdsourcing',
	2 : 'Crowdsourcing acme',
	3 : 'Crowdsourcing acmes',
};



var random_replies = {
	0 : 'I do not know about that. But did you know that Llamas are the camel’s hippie cousins. They belong to a group of animals called camelids that also includes alpacas. All camelids spit or stick out their tongue when they are annoyed.',
	1 : 'I do not quite get it. But did you know that Llama poop has almost no odor. Llama farmers refer to llama manure as "llama beans." It makes for a great, eco-friendly fertilizer. Historically, the Incas in Peru burned dried llama poop for fuel.',
	2 : 'Did you know that Llamas are social animals and prefer to live with other llamas or herd animals. The social structure of llamas changes frequently and a male llama can move up the social ladder by picking, and winning, small fights with the leader of the group.',
	3 : 'Llamas are very gentle, shy, and curious animals.',
	4 : '*spits* Do not ask me intimidating questions',
	5 : 'When one llama has an issue with another llama, it will stick its tongue out to express its displeasure. They’ll also spit on other llamas.',
	6 : 'According to legend, the Spaniards, who had never seen llamas before, kept asking what they were called (“Cómo se llama?”)—and so the Incans thought “llama” was the Spanish name for the animals. But according to the BBC, this story is “not quite accurate. In fact the expression llama was there before the Spanish arrived. It’s of Quechuan origin and was borrowed by many languages, together with other Quechuan words such as condor or puma.',
};

var replies = {
	'where' : {
		'data' : ['vsisasakha \
				virtual community of skilled members to obtain the necessary ideas or services.',
				'Please select from one of the following options to know more about it(on crowdsourcing):'
		],

	},
	
	'benefits' : {
		'data' : ['Crowdsourcing provides the following highlevel advantages:<br><br>\
			-Instant access to net generation skills at scale<br>\
			-Sheilds client from the complexity that comes with onboarding and engaging.'],
		'link' : [ 'You can also find more information about benefits through links.',
				 'https://acmeloremimposum.com/benefits']
	}

}

var main = document.getElementById('main');
var trendingBox = document.getElementById("trending");
var input_user = document.getElementById('input-user');
var input_user_back = document.getElementById('input-user-back');
var close_overlay = document.getElementById('close-overlay');
var overlay = document.getElementById('overlay');
var close_main = document.getElementById('close-main');
var close_fav = document.getElementById('close-fav');
var favorites_note = document.getElementById('favorites-note');
var call_bot = document.getElementById('call-bot');
//the replies with star toggle
var number_of_stars = 0;

//array of time of every msg in chat
var post_times = [];

close_overlay.addEventListener('click', function(){
	overlay.style.display = 'none';
});

close_main.addEventListener('click', function(){
	overlay.style.display ='block';
});


//search sugesstions ----> uses JQUERY-UI complete
$(document).ready(function() {
    var arrayOfOptions = Object.values(suggest_data);

    //search input 
    $("#input-user").autocomplete({

    	//METHODS
    	source: function (request, response) {
	        var results = $.ui.autocomplete.filter(arrayOfOptions, request.term);
	        //when empty input
	        //sets the sugesstion value
	        if (!results.length) {
	        	input_user_back.value = "";
	        	main.style.paddingBottom = 0;
	        }
	        else{
	        	main.style.paddingBottom = (45 * results.length + 50).toString() + 'px';
	        	main.scrollTop = main.scrollHeight;
	        }
	        response(results);
	    },

	    //flips the sugession box - comes up instead of down
    	position: {  collision: "flip" },

    	//when selected(enter or click)
    	//sets the sugesstion value to null
    	select: function( event , ui ) {
			event.preventDefault();

			input_user.value = "";
			input_user_back.value = "";
			main.style.paddingBottom = 0;

			setQuestion(ui.item.label);
		},

		// enter value to placehodler when selected
		focus: function(event, ui){
			input_user_back.value = ui.item.label;

			$("#input-user").val(function () {

				// present length of input
				let input_length = this.value.length;
				return ui.item.label.slice(0,input_length);
			});
			event.preventDefault();
		}

	}).keyup(function (event) {
        event.preventDefault();
	    if (event.keyCode === 13) {
            call_bot.click();
	    }

	    //close the typing pop-up when ESC is pressed
	    if(event.keyCode === 27){
	    	let typing = document.getElementById('typing');
			if(typing){
				typing.parentNode.removeChild(typing);
				main.style.paddingBottom = 0;	
			}
	    }

	//Word matching header
    }).data("autocomplete")._renderMenu = function (ul, items) {
            var self = this;
            $.each(items, function (index, item) {
                self._renderItem(ul, item);

                //html for header
                if (index == 0) ul.prepend(
                	'<div id="suggestions">'
	                	+ '<header><h3>Word Matching</h3>'
		                	+ '<div>'
								+ '<span><div class="updown"></div>to naviage</span>'
								+ '<span><div class="enter"></div>to select</span>'
								+ '<span>esc to dismiss</span>'
							+ '</div>'
						+ '</header>'
					+ '</div>');
            });
	}


	call_bot.addEventListener('click', function(){
		
		var current_search = input_user.value;
		//empty search field
		input_user.value = "";
		input_user_back.value = "";
		main.style.paddingBottom = 0;

		// hide autocomplete
		$(".ui-autocomplete").hide();

		let typing = document.getElementById('typing');
		if(typing){
			typing.parentNode.removeChild(typing);
			main.style.paddingBottom = 0;	
		}

		if(current_search !== '')
			setQuestion(current_search)
	});


	// sets the question properly and calls the bot
	function setQuestion(quest){

		$('#main').append(questionConstructor(quest));
		//making main scroll to bottom
		main.scrollTop = main.scrollHeight;

	
			var temp = random_replies[Math.floor( Math.random()*Object.keys(random_replies).length )];
			callBot(temp);	
	
		
	}

	//rightly to be started after receiving json data
	loadTrending();

});



//dyanmically add event listener to messages with buttons
function addButtonEventListener(button_number){

	var buttons = document.getElementsByClassName('reply-button');

	for(let i = 0; i < button_number; i++){
		
		buttons[i].addEventListener('click', function(){
			if(this.innerHTML === 'Benefits'){
				var button_data = this.innerHTML;

				var buffering = document.getElementById('buffering');
				if(!buffering){
					$('#main').append('<div class="msg-left">\
						<img id="buffering" src="./icons/buffering.png"></div>');

					main.scrollTop = main.scrollHeight;
				}

				var reply_buttons = document.getElementById('reply-buttons')
				reply_buttons.parentNode.removeChild(reply_buttons);
				bufferCall(button_data);
			}
		});	
	}

	// timeout function after buffering
	function bufferCall(button_data){
		setTimeout(function(){
			var buffering = document.getElementById('buffering');
			if(buffering)
				buffering.parentNode.removeChild(buffering);

			$('#main').append(questionConstructor(button_data));

			callBot(replies.benefits.data);
			callBot(replies.benefits.link, 'has_link');	
		}, 2000);
	}
	
}

// trending questions
function loadTrending(){

	for(let i = 0; i < Object.keys(trending_data).length; i++){
		$('#trending').append(
			'<p class="trending-question">' + trending_data[i] + '?' 
			+ '<img src="./icons/yellow_tri.png" /></p>');    
	}

	for(let i = 0; i < Object.keys(trending_data).length; i++){
		$('.trending-question').eq(i).click(function(){
			$('#main').append(questionConstructor(trending_data[i]));
			//making main scroll to bottom
  			main.scrollTop = main.scrollHeight;
  			callBot(trending_answers[i]);
		});
	}
}


//emptires placeholder when the search input is empty
input_user.addEventListener('keyup', function(){
	if(this.value === ''){

		//if empty close typing pop-up
		let typing = document.getElementById('typing');
		if(typing){
			typing.parentNode.removeChild(typing);
			main.style.paddingBottom = 0;	
		}

		input_user_back.value = '';
    	main.style.paddingBottom = 0;
	}
});


input_user.addEventListener('input', function(){
	// declaring locally because its destroyed and created at times
	let typing = document.getElementById('typing');
	if(!typing){
		$('#main').append('<div id="typing" class="msg-right">\
			<div><div></div><div></div><div></div></div>\
		</div> ');
		//making main scroll to bottom
		main.scrollTop = main.scrollHeight;
	}
});

input_user.addEventListener('focusout', function(){

	// declaring locally because its destroyed and created at times
	let typing = document.getElementById('typing');
	if(typing){
		typing.parentNode.removeChild(typing);
		main.style.paddingBottom = 0;		
	}
	
});



function callBot(msg, x){
	var searching = document.getElementById('searching');

	if(!searching){
		$('#main').append('<div id="searching" class="msg-left">\
			<div><div></div><div></div><div></div></div>\
		</div> ');	
	}
	//making main scroll to bottom
	main.scrollTop = main.scrollHeight;

	setTimeout(function(){
		var searching = document.getElementById('searching');
		if(searching)
			searching.parentNode.removeChild(searching);

		if(x === undefined){
			$('#main').append(messageConstructor(msg));	
		}
		else if(x === 'has_buttons'){
			$('#main').append(buttonsConstructor(msg));
			addButtonEventListener(msg.length);
		}

		else if(x === 'has_link'){
			$('#main').append(messageWithLinkConstructor(msg));
			addStarEventListener(number_of_stars++);
		}
		main.scrollTop = main.scrollHeight;

	}, 2000);	
}


// buttons sugesstions constructor
function buttonsConstructor(buttons){

	var total = '<div id="reply-buttons" class="reply some-reply-buttons">';
	buttons.forEach(function(e){
		total += '<button class="reply-button">' + e + '</button>';
	});

	return total + '</div>';
}


// reply message constructor
function messageConstructor(msg){

	post_times.push(new Date());
	$('#main').append('<div class="msg-left reply">'
			+ '<p>' + msg +'</p>'
			+'<span class="time">' + 'Just now' +'</span>'
		+'</div>');
}


// reply message(with link) constructor
function messageWithLinkConstructor(msg){

	post_times.push(new Date());
	return '<div class="msg-left reply has-star">\
			<p>' + msg[0] +
				'<br><a href="#">' + msg[1] + '</a>\
				<img class="white-star" src="./icons/whiteStar.png">\
				<img class="hidden-star" src="./icons/blackStar.svg">\
			</p>\
			<span class="time">' + 'Just now' +'</span>\
		</div>';
}

// search question constructor
function questionConstructor(quest){

	post_times.push(new Date());
	return '<div class="msg-right question">\
			<span class="time">' + 'Just now' +'</span>\
				<p>' + quest +'</p>\
		</div>';
}


// returns current time
function getTime(date) {
	var hours = date.getHours();
	var minutes = date.getMinutes();
	var ampm = hours >= 12 ? 'PM' : 'AM';
	hours = hours % 12;
	hours = hours ? hours : 12;
	minutes = minutes < 10 ? '0'+minutes : minutes;
	var strTime = hours + ':' + minutes + ' ' + ampm;
	return strTime;
}
		

//sets the time of messages
setInterval(function(){

	var times = document.getElementsByClassName('time');
	for(let i = 0; i <  times.length; i++){
		//time elapsed from it was posted
		var elapsed_time = new Date() - post_times[i];
		//two conditions because we dont want to update the old ones
		if( elapsed_time >= 5000 && elapsed_time <= 10000)
			times[i].innerHTML = getTime(post_times[i]);
	}

}, 2000);







