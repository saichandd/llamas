
## Program structure
	* html : home.html
    * css: consists of compiled css from scss
    * fonts: consists of embedded fonts
    * icons: icons and images
    * scripts: consists of js files
    * scss: consists of sass files
    * index.php : small server 

##Note

1.SVG are used if possible, or else sprites are used when needed.
2.Sometimes png instead of sprites to increase initial loading speed. i.e; when those images are needed dynamically(when creating elements)
3.Also large images arent included in sprites as it will stop others from showing up
4.Comments not given for self explanatory code

##Heroku Link
https://chatbot-ui.herokuapp.com/


##Local setup

open **home.html**


##How to set-up your own app on Heroku

# Steps

1. Create new app in Heroku
2. Create a new Git repository
3. Commit your code to the repository and deploy it to Heroku using Git.
4. Run `git push heroku master`


